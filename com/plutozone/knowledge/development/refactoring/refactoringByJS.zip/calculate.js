/**
 * YOU ARE STRICTLY PROHIBITED TO COPY, DISCLOSE, DISTRIBUTE, MODIFY OR USE THIS PROGRAM
 * IN PART OR AS A WHOLE WITHOUT THE PRIOR WRITTEN CONSENT OF PLUTOZONE.COM.
 * PLUTOZONE.COM OWNS THE INTELLECTUAL PROPERTY RIGHTS IN AND TO THIS PROGRAM.
 * COPYRIGHT (C) 2026 PLUTOZONE.COM ALL RIGHTS RESERVED.
 *
 * 하기 프로그램에 대한 저작권을 포함한 지적재산권은 plutozone.com에 있으며,
 * plutozone.com이 명시적으로 허용하지 않는 사용, 복사, 변경 및 제 3자에 의한 공개, 배포는 엄격히 금지되며
 * plutozone.com의 지적재산권 침해에 해당된다.
 * Copyright (C) 2026 plutozone.com All Rights Reserved.
 *
 *
 * Program		: com.plutozone.knowledge
 * Description	:
 * Environment	: JavaScript
 * File			: calculator.js
 * Notes		:
 * History		: [NO][Programmer][Description]
 *				: [202606301630][pluto#plutozone.com][CREATE: Initial Release]
 */
class Calculator {

	constructor(aPerformance, aPlay) {
		this.performance	= aPerformance;
		this.play			= aPlay;
	}
	
	get amount() {
		throw new Error("서브 클래스에서 처리하도록 설계되었습니다.");
	}
	
	get volumeCredits() {
		return Math.max(this.performance.audience - 30, 0);
	}
}

class TragedyCalculator extends Calculator {
	
	get amount() {
		let result = 40000;
		if (this.performance.audience > 30) {
			result += 1000 * (this.performance.audience - 30);
		}
		
		return result;
	}
}

class ComedyCalculator extends Calculator {
	
	get amount() {
		let result = 30000;
		if (this.performance.audience > 20) {
			result += 10000 + 500 * (this.performance.audience - 20);
		}
		result += 300 * this.performance.audience;
		
		return result;
	}
	
	get volumeCredits() {
		return super.volumeCredits + Math.floor(this.performance.audience / 5);
	}
}

function calculate(invoice, plays) {

	const result = {};
	result.customer				= invoice.customer;
	result.performances			= invoice.performances.map(enrichPerformance);
	result.totalAmount			= totalAmount(result);
	result.totalVolumeCredits	= totalVolumeCredits(result);
	
	return result;
	
	function enrichPerformance(aPerformance) {
		
		const calculator		= createCalculator(aPerformance, playFor(aPerformance));
		const result			= Object.assign({}, aPerformance);
		
		result.play				= calculator.play;
		result.amount			= calculator.amount;
		result.volumeCredits	= calculator.volumeCredits;
		
		return result;
	}
	
	function createCalculator(aPerformance, aPlay) {
		switch (aPlay.type) {
			case "tragedy"	: return new TragedyCalculator(aPerformance, aPlay);
			case "comedy"	: return new ComedyCalculator(aPerformance, aPlay);
			default:
				throw new Error(`알 수 없는 장르: ${aPlay.type}`);
		}
	}
	
	// 총액
	function totalAmount(data) {
		
		return data.performances
			.reduce((total, p) => total + p.amount, 0);
	}
	
	// 적립 포인트
	function totalVolumeCredits(data) {
		
		return data.performances
			.reduce((total, p) => total + p.volumeCredits, 0);
	}
	
	// 연극
	function playFor(aPerformance) {
		return plays[aPerformance.playID];
	}
}

module.exports = calculate;