/**
 * YOU ARE STRICTLY PROHIBITED TO COPY, DISCLOSE, DISTRIBUTE, MODIFY OR USE THIS PROGRAM
 * IN PART OR AS A WHOLE WITHOUT THE PRIOR WRITTEN CONSENT OF PLUTOZONE.COM.
 * PLUTOZONE.COM OWNS THE INTELLECTUAL PROPERTY RIGHTS IN AND TO THIS PROGRAM.
 * COPYRIGHT (C) 2026 PLUTOZONE.COM ALL RIGHTS RESERVED.
 *
 * 하기 프로그램에 대한 저작권을 포함한 지적재산권은 plutozone.com에 있으며,
 * plutozone.com이 명시적으로 허용하지 않는 사용, 복사, 변경 및 제 3자에 의한 공개, 배포는 엄격히 금지되며
 * plutozone.com의 지적재산권 침해에 해당된다.
 * Copyright (C) 2026 plutozone.com All Rights Reserved.
 *
 *
 * Program		: com.plutozone.knowledge
 * Description	:
 * Environment	: JavaScript
 * File			: statement.js
 * Notes		:
 * History		: [NO][Programmer][Description]
 *				: [202606301630][pluto#plutozone.com][CREATE: Initial Release]
 */
const calculate = require("./calculate");

function text(invoice, plays) {
	return renderText(calculate(invoice, plays));
}

function renderText(data) {
	
	let result = `청구 내역(고객명: ${data.customer})\n`;
	
	// 청구 내역들
	for (let perf of data.performances) {		
		result += `${perf.play.name}: ${usd(perf.amount)}(${perf.audience}석)\n`;
	}
	
	result += `총액: ${usd(data.totalAmount)}\n`;
	result += `적립 포인트: ${data.totalVolumeCredits}점\n`;
	
	return result;
}

function html(invoice, plays) {
	return renderHTML(calculate(invoice, plays));
}

function renderHTML(data) {
	
	let result = `<h1>청구 내역(고객명: ${data.customer})</h1>\n`;
	result += "<table>\n";
	result += "<tr><th>연극</th><th>금액(좌석수)</th></tr>";
	for (let perf of data.performances) {
		result += `<tr><td>${perf.play.name}</td><td>${usd(perf.amount)}`;
		result += `(${perf.audience}석)</td></tr>\n`;
	}
	result += "</table>\n";
	
	result += `<p>총액: <em>${usd(data.totalAmount)}</em></p>\n`;
	result += `<p>적립 포인트: <em>${data.totalVolumeCredits}</em>점</p>\n`;
	
	return result
	
}

// 달러 표시
function usd(aNumber) {
	return new Intl.NumberFormat("en-US",
					{style:"currency"
					, currency: "USD"
					, minimumFractionDigits: 2}).format(aNumber/100);
}

module.exports = {text, html};